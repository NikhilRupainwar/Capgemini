﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfDemo_ObjectBinding
{
    class ProductStore
    {
        /*Using Normal Property won't bind the values in the TextBox back to the object
        One-way Binding */

        public ProductDependency GetProduct()
        {
            ProductDependency prod = new ProductDependency { ProductName = "MobilePhone", Category = "Electronics" };
            return prod;
        }

        /* Using the Properties created inside the class that implements 
        INotifyPropertyChanged Interface  created the dependancy between the object and Binding Control
         Two-Way Binding is possible.Changes made in the Textbox reflects the object values */
        //public ProductDependency GetProducts()
        //{
        //    ProductDependency prod = new ProductDependency { ProductName = "MobilePhone", Category = "Electronics" };
        //    return prod;
        //}

    }
}
