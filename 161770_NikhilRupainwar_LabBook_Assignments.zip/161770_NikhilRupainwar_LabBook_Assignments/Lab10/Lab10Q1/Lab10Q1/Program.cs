﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10Q1
{
    //create delegate
    delegate int PerformArithmeticOperation(int num1, int num2);
    class ArithmeticOperation
    {
        //operation method with delegate operation
        public static void DoOperation(int num1, int num2, PerformArithmeticOperation arOperation)
        {
            int z = arOperation(num1, num2);
            Console.WriteLine("{0} and {1} is:::{2}", num1, num2, z);
        }

        //Add Method
        public int Add(int num1, int num2)
        {
            return num1 + num2;


        }

        //substraction method
        public int Sub(int num1, int num2)
        {
            return num1 - num2;

        }

        //Multiplication method
        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }

        //Division method
        public int Divide(int num1, int num2)
        {
            return num1 / num2;
        }

        //finding maximum between two numbers 
        public int Max(int num1, int num2)
        {
            return num1 > num2 ? num1 : num2;
        }


        public static void Main()
        {
            int ch, num1, num2;
            ArithmeticOperation ap = new ArithmeticOperation();
            do
            {
                //Taking User Choice
                Console.WriteLine("******************************");
                Console.WriteLine("1.Addition::");
                Console.WriteLine("2.Subtraction::");
                Console.WriteLine("3.Multiplication::");
                Console.WriteLine("4.Division::");
                Console.WriteLine("5.Maximum number::");
                Console.WriteLine("******************************");

                //Taking User Choice
                Console.WriteLine("enter choice::");
                ch = Convert.ToInt32(Console.ReadLine());


                switch (ch)
                {
                    case 1:

                        //taking user input number1 and number2
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        DoOperation(num1, num2, ap.Add);
                        break;

                    case 2:

                        //taking user input number1 and number2
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        DoOperation(num1, num2, ap.Sub);
                        break;

                    case 3:
                        //taking user input number1 and number2
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        DoOperation(num1, num2, ap.Multiply);
                        break;

                    case 4:

                        //taking user input number1 and number2
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        DoOperation(num1, num2, ap.Divide);
                        break;

                    case 5:
                        //taking user input number1 and number2
                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());
                        DoOperation(num1, num2, ap.Max);
                        break;
                    //case for exit
                    case 6:
                        Environment.Exit(0);
                        break;

                    //default case for invalide vhoice
                    default:
                        Console.WriteLine("Enter Valid Choice:");
                        break;

                }
            } while (ch != 6);
            Console.ReadKey();
        }

    }
}

