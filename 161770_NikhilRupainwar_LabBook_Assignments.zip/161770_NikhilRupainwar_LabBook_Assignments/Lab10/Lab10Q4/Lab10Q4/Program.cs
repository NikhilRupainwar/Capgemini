﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab10Q4
{
    delegate int Deligate(int num1, int num2);
    class ArithmeticOperations
    {
        static int num;

        //Addition  of two number
        public static int AddNum(int num1, int num2) => num = num1 + num2;
        //Substraction  of two number
        public static int SubNum(int num1, int num2) => num = num1 - num2;
        //Multiplication  of two number
        public static int MultNum(int num1, int num2) => num = num1 * num2;
        //Division  of two number
        public static int DivNum(int num1, int num2) => num = num1 / num2;
        //Maximum of two number
        public static int MaxNum(int num1, int num2) => (num1 > num2) ? num1 : num2;


        static void Main(string[] args)
        {
            int ch, num1, num2;
            do
            {
                //print Menu
                Console.WriteLine("Menu");
                Console.WriteLine("1.Addition::");
                Console.WriteLine("2.Subtraction::");
                Console.WriteLine("3.Multiplication::");
                Console.WriteLine("4.Divition::");
                Console.WriteLine("5.Maximum number::");

                Console.WriteLine("enter choice::");
                ch = Convert.ToInt32(Console.ReadLine());

                switch (ch)
                {
                    //Case for Addition of two number
                    case 1:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        Deligate nc1 = new Deligate(AddNum);
                        int sum = nc1.Invoke(num1, num2);

                        Console.WriteLine("result: {0}", sum);
                        break;


                    //Case for Substraction of two number
                    case 2:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        Deligate nc2 = new Deligate(SubNum);
                        int sub = nc2(num1, num2);

                        Console.WriteLine("result: {0}", sub);
                        break;

                    //Case for Multiplication of two number
                    case 3:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        Deligate nc3 = new Deligate(MultNum);
                        int mul = nc3(num1, num2);

                        Console.WriteLine("result: {0}", mul);
                        break;

                    //Case for Division of two number
                    case 4:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        Deligate nc4 = new Deligate(DivNum);
                        int div = nc4(num1, num2);

                        Console.WriteLine("result: {0}", div);
                        break;

                    //Case for Maximum of two number
                    case 5:

                        Console.WriteLine("enter 1st number::");
                        num1 = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("enter 2st number::");
                        num2 = Convert.ToInt32(Console.ReadLine());

                        Deligate nc5 = new Deligate(MaxNum);
                        int max = nc5(num1, num2);

                        Console.WriteLine("result: {0}", max);
                        break;

                        //Exit
                    case 6:
                        Environment.Exit(0);
                        break;

                        //default case for oinvalid operation
                    default:
                        Console.WriteLine("invalid choice");
                        break;
                }
            } while (ch != 6);
         
        }
    }
}
