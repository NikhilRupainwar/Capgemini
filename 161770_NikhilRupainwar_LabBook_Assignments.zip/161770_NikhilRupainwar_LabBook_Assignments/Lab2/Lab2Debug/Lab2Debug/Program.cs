﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Debug
{

    class ArrayHelper
    {
        //public specifier Added 
        public static int[] numbers = null;  

        //access specifiers "P" should be "p"
        public ArrayHelper(params int[] arr) 
        {

        }

        //name of array no space  and provide parameter
        public void SortArray(int[] numbers) 
        {
            //remove +1 from for loop condition
            for (int i = 0; i < numbers.Length ; i++)
            {
                //remove -1 from for loop condition 
                for (int j = 0; j < numbers.Length; j++) 
                {
                    if (numbers[i] < numbers[j])
                    {
                        int temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }
                }
            }
        }

        // method should have parameter
        public void PrintNumbers(int[] numbers)
        {
            foreach (int num in numbers)
            {
                Console.Write("{0} ", num);
            }
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to debugging\n");
            try
            {
                //object should be created
                ArrayHelper arrhelperObj = new ArrayHelper();

                // array should be passed
                arrhelperObj.SortArray(ArrayHelper.numbers);

                // array should be passed 
                arrhelperObj.PrintNumbers(ArrayHelper.numbers); 
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
        
    }
    
}
