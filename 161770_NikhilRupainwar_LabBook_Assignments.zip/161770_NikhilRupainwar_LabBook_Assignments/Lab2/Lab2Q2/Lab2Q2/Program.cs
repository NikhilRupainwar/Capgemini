﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            //multidiamentional Array declaration
            int[,] multiDArray = new int[5, 6];

            
            Console.WriteLine("Enter values in Two dimention array:");
            //loop for rows
            for (int i = 0; i < multiDArray.GetLength(0); i++)
            {
                //loop for colunms
                for (int j = 0; j < multiDArray.GetLength(1); j++)
                {
                    Console.Write("Enter value for position[{0},{1}]:", i, j);
                    // convert string values to integer values
                    multiDArray[i, j] = int.Parse(Console.ReadLine());
                }
            }

            //Display Two Diamention Array
            Console.WriteLine("Values in the Array:");
            for (int i = 0; i < multiDArray.GetLength(0); i++)
            {
                Console.WriteLine();
                for (int j = 0; j < multiDArray.GetLength(1); j++)
                {
                    Console.Write(multiDArray[i, j] + " ");
                }
            }

            Console.ReadKey();
        }
    }
}
