﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q_2
{
    public class Circle : Shape
    {
        //void WhoamI()[ERROR]
        //( Child class method should contain override keyword in order to override the parent class method )

        public override void WhoamI()
        {
            Console.WriteLine("I m Circle");
        }
    }
}
