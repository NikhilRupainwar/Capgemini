﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCaseDemoQ3
{
    class Program
    {
        static void Main(string[] args)
        {

            int number;
            //Taking input from user
            Console.Write("Enter Number: ");
            number = Convert.ToInt32(Console.ReadLine());

            switch (number)
            {
                //message for case 1
                case 1:
                    Console.WriteLine("Entered Number is: " + number);
                    break;

                //message for case 2
                case 2:
                    Console.WriteLine("Entered Number is: " + number);
                    break;

                //message for case 3
                case 3:
                    Console.WriteLine("Entered Number is: " + number);
                    break;

                //message for case 4
                case 4:
                    Console.WriteLine("Entered Number is: " + number);
                    break;

                //message for case 5
                case 5:
                    Console.WriteLine("Entered Number is: " + number);
                    break;

                //message for default or wrong entry case
                default:
                    Console.WriteLine("Entered Wrong number ");
                    break;
            }

            Console.ReadKey();
        }
    }
}
