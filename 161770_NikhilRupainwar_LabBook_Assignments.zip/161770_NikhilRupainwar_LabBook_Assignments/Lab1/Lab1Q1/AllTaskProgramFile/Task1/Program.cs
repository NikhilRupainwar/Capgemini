﻿//Console File for Employee class
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ABCLtd;
namespace Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[10];// Array of object creation and initialization

            Console.WriteLine("Enter Empolyee Details:");
            for (int i = 0; i < emp.Length; i++)
            { 
                Console.WriteLine("Enter details for Employee:" + i);
                emp[i] = new Employee();// Actual Object creation inside loop

                //Taking Employee Details from user
                Console.WriteLine("Employee ID:");            
                emp[i].EmployeeId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Employee Name:");
                emp[i].EmployeeName = Console.ReadLine();

                Console.WriteLine("Employee Address:");
                emp[i].EmployeeAddress = Console.ReadLine();

                Console.WriteLine("Employee City:");
                emp[i].EmployeeCity = Console.ReadLine();

                Console.WriteLine("Employee Department:");
                emp[i].EmployeeDepartment = Console.ReadLine();

                Console.WriteLine("Employee Salary:");
                emp[i].Salary = Convert.ToDouble(Console.ReadLine());
            }

            //Display Employee Name and Salary
            Console.WriteLine("*****Employee Details*****");
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("Employee Name:"+emp[i].EmployeeName);
                Console.WriteLine("Employee Salary:"+emp[i].Salary);
            }

            Console.ReadKey();
        }
    }
}
