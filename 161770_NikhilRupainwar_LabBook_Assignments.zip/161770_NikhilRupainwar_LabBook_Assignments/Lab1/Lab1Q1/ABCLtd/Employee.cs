﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABCLtd
{
    public class Employee
    {
       //Using Property Values are aisigned and access 
        public int EmployeeId { private get;  set; }
        public string EmployeeName { get;  set;  }
        public string EmployeeAddress {private get; set; }
        public string EmployeeCity {private get;  set; }
        public string EmployeeDepartment {private get; set; }
        public double Salary { get; set; }

    }
}
