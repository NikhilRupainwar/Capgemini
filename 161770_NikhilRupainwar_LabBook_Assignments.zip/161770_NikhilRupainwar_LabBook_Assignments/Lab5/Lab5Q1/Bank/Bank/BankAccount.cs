﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bank
{
    //Enum type definition to specify possible set of values 
    public enum BankAccountTypeEnum { Current = 1, Saving = 2 }

    //interface declaration
    interface IBankAccount
    {
        double GetBalance();
        void Deposit(double amount);
        bool Withdraw(double amount);
        bool Transfer(BankAccount toAccount, double amount);
        BankAccountTypeEnum AccountType { get; set; }

    }

    //Abstract class declaration
    public abstract class BankAccount : IBankAccount
    {
        protected double balance;

        public double Balance
        {
            set { balance = value; }
            get { return balance; }
        }

        //Deposit method declaration and body
        public void Deposit(double amount)
        {
            Balance = amount;
        }

        //Abstract method declaration
        public abstract double GetBalance();
        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(BankAccount toAccount, double amount);
        public BankAccountTypeEnum AccountType { get; set; }

    }
}
