﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3Q4
{
    public class Supplier
    {
        private int supplierId;
        public int SupplierID { get { return supplierId; } set { supplierId = value; } }

       
        private string supplierName;
        public string SupplierName { get { return supplierName; } set { supplierName = value; } }

        private string city;
        public string City { get { return city; } set { city = value; } }

        private string phoneNo;
        public string Phone { get { return phoneNo; } set { phoneNo = value; } }

        private string email;
        public string Email { get { return email; } set { email = value; } }


        public void AcceptDetails(Supplier s)
        {
            Console.WriteLine("Enter Supplier Details:");

            Console.Write("Enter Supplier Id:");
            s.SupplierID = Convert.ToInt32(Console.ReadLine());

            Console.Write("Supplier Name:");
            s.SupplierName = Console.ReadLine();

            Console.Write("Supplier City:");
            s.City = Console.ReadLine();

            Console.Write("Supplier PhoneNo:");
            s.Phone = Console.ReadLine();

            Console.Write("Supplier Email:");
            s.Email = Console.ReadLine();

        }

        public Supplier DisplayDetails()
        {
            Supplier s = this;
            return s;

        }
    }
}
