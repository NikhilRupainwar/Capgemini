﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    [AttributeUsage(AttributeTargets.Class|AttributeTargets.Method)]
    class AuthorAttribute:Attribute
    {
        public string AuthorName { get; set; }
        public AuthorAttribute(string name)
        {
            AuthorName = name;

        }

    }
}
