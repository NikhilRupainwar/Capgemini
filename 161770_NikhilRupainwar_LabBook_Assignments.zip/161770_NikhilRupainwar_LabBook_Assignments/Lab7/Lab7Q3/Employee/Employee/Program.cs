﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    class Program
    {
        static void Main(string[] args)
        {
            AuthorAttribute atr = (AuthorAttribute)Attribute.GetCustomAttribute(typeof(Product), typeof(AuthorAttribute));


            if (atr == null)
                Console.WriteLine("Author Attribute not applied on Product class ");
            else
                Console.WriteLine("Author name for class product is: " + atr.AuthorName);

            Console.ReadKey();
        }
    }
}
