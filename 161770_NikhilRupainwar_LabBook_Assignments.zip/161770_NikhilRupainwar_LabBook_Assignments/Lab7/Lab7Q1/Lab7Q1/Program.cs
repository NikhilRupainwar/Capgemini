﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab7Q1
{
    class Program
    {
        //Method for printing Menu
        public static void PrintMenu()
        {

            Console.WriteLine("\n1. Add Contact");
            Console.WriteLine("2. Display Contact");
            Console.WriteLine("3. Edit Contact");
            Console.WriteLine("4. ShowAll Contacts");
            Console.WriteLine("5. Exit");

        }

        //Method to add contact in list
        public static void AddContact(ref List<Contact> MyContactList)
        {
            //Contact class Object creation
            Contact NewContact = new Contact();

            //taking user input for contact details
            Console.Write("Enter Contact Number : ");
            NewContact.ContactNo = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter Contact Name : ");
            NewContact.ContactName = Console.ReadLine();

            Console.Write("Enter Cell Number : ");
            NewContact.CellNo = Console.ReadLine();

            //adding contact object to List
            MyContactList.Add(NewContact);
        }

        //method to display perticular contact
        public static void DisplayContact(ref List<Contact> MyContactList)
        {
            //Taking User input name for perticular contact for display
            Console.Write("Enter Name of Contact You Want To View : ");
            string ContactName = Console.ReadLine();

            //find and store contact object from MyContactList
            Contact contact = MyContactList.Find(c => c.ContactName == ContactName);
            if (contact != null)
            {
                //Displaying Details
                Console.WriteLine("\nContact No. : " + contact.ContactNo);
                Console.WriteLine("Conact Name. : " + contact.ContactName);
                Console.WriteLine("Cell No. : " + contact.CellNo);
            }
            else
                Console.WriteLine("No Contact Found");
        }

        //method to update perticular contact
        public static void EditContact(ref List<Contact> MyContactList)
        {

            //Taking User input name for perticular contact for Update
            Console.Write("Enter Name of Contact You Want To Update : ");
            string UpdateQueryName = Console.ReadLine();

            //find and store contact object from MyContactList to update
            Contact ContactToBeUpdated = MyContactList.Find(c => c.ContactName == UpdateQueryName);
            if (ContactToBeUpdated != null)
            {

                //taking details from user for update
                Console.Write("\nEnter New Contact No. : ");
                ContactToBeUpdated.ContactNo = Convert.ToInt32(Console.ReadLine());

                Console.Write("\nEnter New Contact Name : ");
                ContactToBeUpdated.ContactName = Console.ReadLine();

                Console.Write("\nEnter New Cell No. : ");
                ContactToBeUpdated.CellNo = Console.ReadLine();

                //updating MyContactList
                MyContactList[MyContactList.IndexOf(ContactToBeUpdated)] = ContactToBeUpdated;
                Console.WriteLine("\nContact Updated Successfully\n");
            }
            else
                Console.WriteLine("No Saved Details Found,Contact Not Updated");
        }

        //method to display All contact
        public static void ShowAllContacts(ref List<Contact> MyContactList)
        {
            if (MyContactList != null)
            {
                //foreach loop for iterate list
                foreach (Contact SavedContact in MyContactList)
                {
                    //Displaying Details
                    Console.WriteLine("Contact No. : " + SavedContact.ContactNo);
                    Console.WriteLine("Contact Name : " + SavedContact.ContactName);
                    Console.WriteLine("Cell No. : " + SavedContact.CellNo);
                }

            }
            else
                Console.WriteLine("No Details Saved Yet Please SAve Some Contatcs Fitrst");
        }

        static void Main(string[] args)
        {
            int choice;
            //creating object for generic class list of type contact
            List<Contact> MyContactList = new List<Contact>();
            do
            {
                Console.Write("\nChoose Operation :  ");
                //calling PrintMenu method 
                PrintMenu();
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    //case1 for Add Contact
                    case 1:
                        Program.AddContact(ref MyContactList);
                        break;

                    //case2 for Display perticular Contact
                    case 2:
                        Program.DisplayContact(ref MyContactList);
                        break;

                    //case2 for  update Contact
                    case 3:
                        Program.EditContact(ref MyContactList);
                        break;

                    //case2 for Display All Contact
                    case 4:
                        Program.ShowAllContacts(ref MyContactList);

                        break;

                    //case5 for Exit
                    case 5:
                        Environment.Exit(0);
                        break;

                    //default case for invalid choice
                    default:
                        Console.WriteLine("enter A Valid Choice");
                        break;

                }
            }
            while (choice != 5);

        }
    }
}
