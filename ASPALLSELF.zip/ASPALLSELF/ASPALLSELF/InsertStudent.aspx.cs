﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ASPALLSELF
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["str"].ConnectionString);
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("insert into Nikhil.StudentMaster(StudentCode,StudentName,DeptCode,StudentDOB,StudentCity) values(@StudentCode,@StudentName,@DeptCode,@StudentDOB,@StudentCity)", con);
            cmd.Parameters.AddWithValue("@StudentCode", txtCode.Text);
            cmd.Parameters.AddWithValue("@StudentName", txtName.Text);

            cmd.Parameters.AddWithValue("@DeptCode", txtDCode.Text);
            cmd.Parameters.AddWithValue("@StudentDOB", Convert.ToDateTime(txtDOB.Text));
            cmd.Parameters.AddWithValue("@StudentCity", txtAddress.Text);
            con.Open();
            int rowsAffected = Convert.ToInt32(cmd.ExecuteNonQuery());
            con.Close();
            if (rowsAffected > 0)
            {
                Response.Write("<script type='text/javascript'>alert('Student Data Inserted');</script>");
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('Student Data Not Inserted');</script>");
            }
        }
    }
}