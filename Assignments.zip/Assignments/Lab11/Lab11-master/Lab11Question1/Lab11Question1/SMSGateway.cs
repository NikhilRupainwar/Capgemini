﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11Question1
{
    class SMSGateway
    {
        static public void SendMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
