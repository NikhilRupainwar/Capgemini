﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection.Bi

namespace Lab13Debug
{
    public class CustomerManager
    {
        static List<Customer> custList = new List<Customer>();

        public CustomerManager()
        {
            custList.Add(new Customer
            {
                CustomerID = 1001,
                Name = "Ramesh",
                Gender = 'M',
                Address = "#104 Mahaveer Springs Mumbai"
            });

            custList.Add(new Customer
            {
                CustomerID = 1002,
                Name = "Ruchi Shah",
                Gender = 'F',
                Address = "#104 Jain Skyline Pune"
            });


        }


        public void Serialize(string path)
        {
            FileStream fs = new FileStream(path, FileMode.CreateNew);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fs, custList);
            Console.WriteLine("Customer List Serialized");
        }

        public void DeSerialize(string path)
        {
            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);// Add fileMode as open and fileAccess as Read
            BinaryFormatter formatter = new BinaryFormatter();
            List<Customer> obj = (List<Customer>)formatter.Deserialize(fs);//use type casting
            fs.Close();
            Print(obj);
        }

        private void Print(List<Customer> obj)
        {
            foreach (Customer item in obj)
            {
                Console.WriteLine("{0}\n{1}\n{2}\n{3}\n",
                    item.CustomerID, item.Name, item.Gender, item.Address);
            }
        }
    }
}
