﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13Debug
{
    public class Customer
    {
        public int CustomerID { get; set; }
        public string Name { get; set; }
        public char Gender { get; set; }

        [NonSerialized]
        private string address;
        public string Address
        {
            get { return address; }
            set { address = value; }
        }
    }
}
