﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab13Debug
{
    class Program
    {
        static void Main(string[] args)
        {
            static CustomerManager cm = new CustomerManager(); //Create Object For  CustomerManager Class 
            static void Serialize()
    {
                CustomerManager cm = new CustomerManager();
                Console.WriteLine("Enter the file path.");
                cm.Serialize(Console.ReadLine());
            }

            static void PrintMenu()
    {
                Console.WriteLine("{0}\n{1}\n{2}\n{3}\n\n{4}",
                        "Welcome to Serialization Debugging Demo",
                        "1. Serailize Data", "2. Deserialize Data",
                        "3. Exit the Application.",
                        "Enter your choice");
            }
            static void Deserialize()
    {
                Console.WriteLine("Enter the file path.");
                cm.DeSerialize(Console.ReadLine());
            }
            static void Main(string[] args)
    {
                try
                {
                    int choice = 0;
                    do
                    {
                        PrintMenu();
                        choice = Convert.ToInt32(Console.ReadLine());
                        switch (choice)
                        {
                            case 1:
                                Serialize();
                                break;
                            case 2:
                                Deserialize();
                                break;
                            case 3:
                                Environment.Exit(0);
                                break;
                            default:
                                break;
                        }
                    } while (choice != 3);
                }
                catch (NullReferenceException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                catch (IOException ex)
                {
                    Console.WriteLine(ex.Message);
                }
                Console.ReadKey();
            }


        
    }
    }
}
