﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird
{
    class Bird //cannot be defined as private
    {
        public string Name;
        public double Maxheight;

        public Bird()  //Default Constructor
        {
            this.Name = "Mountain Eagle"; //Quotes
            this.Maxheight = 500;       //No Quotes

            //
            // TODO: Add constructor logic here
            //
        }

        public Bird(string birdname, double max_ht) //Overloaded Constructor
        {
            this.Name = birdname; //birdName
            this.Maxheight = 0; //00
        }

        public void fly()
        {
            Console.WriteLine(Name + " is flying at altitude " + Maxheight);
        }

        public void fly(string AtHeight)
        {
            if (AtHeight <= this.Maxheight)
                Console.WriteLine(this.Name + " flying at " + AtHeight.ToString());
            else

                Console.WriteLine(this.Name +  "cannot fly at this height");
        }
    }

}