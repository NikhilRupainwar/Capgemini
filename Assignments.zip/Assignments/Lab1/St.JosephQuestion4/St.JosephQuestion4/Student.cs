﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace St.JosephQuestion4
{
    class Student
    {
        //Properties are used to get and set the valus 
        public int RollNumber { get; set; }
        public string StudentsName { get; set; }
        public int Age { get; set; }
        public char Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
        public float Percentage { get; set; }
    }
}
