﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Q2
{
    public class mathLib
    {
        public int Add(int num1, int num2)
        {
            return num1 + num2;
        }
        public int Subtract(int num1, int num2)
        {
            return num1 - num2;
        }
        public int Multiply(int num1, int num2)
        {
            return num1 * num2;
        }
        public int Divide(int num1, int num2)
        {
            return num1 / num2;
        }
        public int Modulo(int num1, int num2)
        {
            return num1 % num2;
        }

        public double DAdd(double num1, double num2)
        {
            return num1 + num2;
        }
        public double DSubtract(double num1, double num2)
        {
            return num1 - num2;
        }
        public double DMultiply(double num1, double num2)
        {
            return num1 * num2;
        }
        public double DDivide(double num1, double num2)
        {
            return num1 / num2;
        }
        public double DModulo(double num1, double num2)
        {
            return num1 % num2;
        }

    }
}
