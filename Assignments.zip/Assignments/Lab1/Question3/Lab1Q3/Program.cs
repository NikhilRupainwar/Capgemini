﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[10];
            Console.WriteLine("Enter numbers for array");
            for(int i=0; i < arr.Length; i++)
            {
                arr[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < arr.Length; i++)
            {
                switch(arr[i])
                {
                    case 1:
                        Console.WriteLine("The number is 1");
                        break;
                    case 2:
                        Console.WriteLine("The number is 2");
                        break;
                    case 3:
                        Console.WriteLine("The number is 3");
                        break;
                    case 4:
                        Console.WriteLine("The number is 4");
                        break;
                    case 5:
                        Console.WriteLine("The number is 5");
                        break;
                    default:
                        Console.WriteLine("Error, Reenter data");
                        break;
                        Console.ReadKey();

                }
            }


        }
    }
}
