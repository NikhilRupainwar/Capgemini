﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1Q2;
namespace Lab1Q2
{
    class Program
    {
        public static void Main(string[] args)
        {
            mathLib obj = new mathLib();
           
            Console.WriteLine("If entering numbers in Integer, Press 1 or for double, Press 2 :");
            int ch = Convert.ToInt32(Console.ReadLine());
            if (ch == 1)
            {
                Console.WriteLine("Enter two numbers in Integer");
                int num1 = Convert.ToInt32(Console.ReadLine());
                int num2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Press 1 for Subtraction, Press 2 for Division, Press 3 for Addition, Press 4 for Multiplication, Press 5 for Modulus");
                int c1 = Convert.ToInt32(Console.ReadLine());
                switch(c1)
                {
                    case 1:
                        int sub = obj.Subtract(num1, num2);
                        Console.WriteLine("Subtraction of two numbers is :" + sub);
                        break;
                    case 2:
                        int div = obj.Divide(num1, num2);
                        Console.WriteLine("Division of two numbers is :" + div);
                        break;
                    case 3:
                        int add = obj.Add(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + add);
                        break;
                    case 4:
                        int mult = obj.Multiply(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + mult);
                        break;
                    case 5:
                        int mod = obj.Modulo(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + mod);
                        break;
                    default:
                        Console.WriteLine("Wrong input");
                        break;

                }
            }
            else if (ch == 2)
            {
                Console.WriteLine("Enter two numbers in Double");
                double num1 = Convert.ToDouble(Console.ReadLine());
                double num2 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Press 1 for Subtraction, Press 2 for Division, Press 3 for Addition, Press 4 for Multiplication, Press 5 for Modulus");
                int c2 = Convert.ToInt32(Console.ReadLine());
                switch(c2)
                {
                    case 1:
                        double sub1 = obj.DSubtract(num1, num2);
                        Console.WriteLine("Subtraction of two numbers is :" + sub1);
                        break;
                    case 2:
                        double div1 = obj.DDivide(num1, num2);
                        Console.WriteLine("Division of two numbers is :" + div1);
                        break;
                    case 3:
                        double add1 = obj.DAdd(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + add1);
                        break;
                    case 4:
                        double mult1 = obj.DMultiply(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + mult1);
                        break;
                    case 5:
                        double mod1 = obj.DModulo(num1, num2);
                        Console.WriteLine("Addition of two numbers is :" + mod1);
                        break;
                    default:
                        Console.WriteLine("Wrong input");
                        break;


                }
            }
            else
                Console.WriteLine("Invalid Input");
            Console.ReadKey();
        }
    }
}
