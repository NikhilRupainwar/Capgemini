﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q_2
{
    public class Triangle : Shape
    {

        //public virtual void WhoamI()[ERROR]
        //( Child class should override the parent class method )

        public override void WhoamI()
        {
            Console.WriteLine("I m Triangle");
        }

    }

}
