﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4Q_2
{
    public class Shape
    {
        //private void WhoamI()[ERROR]
        //( Parent Class should contain virtual method for the child class to override and access should be public )

        public virtual void WhoamI()
        {
            Console.WriteLine("I m Shape");
        }

    }
}
