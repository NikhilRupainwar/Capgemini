﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter number of cities");
            int n = Convert.ToInt32(Console.ReadLine());
            string[] array1 = new string[n];
            Console.WriteLine("Enter name of cities as data for array");
            for (int i = 0; i < array1.Length; i++)
            {
                array1[i] = (Console.ReadLine());
            }
            for (int j = 0; j < array1.Length; j++)
            {
                Console.WriteLine("The Elements of array are :" + array1[j]);
            }
            Console.ReadKey();
        }
    }
}
