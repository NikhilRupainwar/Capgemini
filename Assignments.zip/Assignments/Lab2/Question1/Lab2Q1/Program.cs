﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number for which square or cube is to be calculated");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Press 1 for square or press 2 for cube :");
            int ch = Convert.ToInt32(Console.ReadLine());
            cal c = new cal(n);
            switch (ch)
            {
                case 1:
                    Console.WriteLine(c.square());
                    break;
                case 2:
                    Console.WriteLine(c.cube());
                    break;
                default:
                    Console.WriteLine("Invalid Choice");
                    break;
            }
            Console.ReadKey();
        }
    }
    public struct cal
    {
        int Number;
        public cal(int Number)
        {
            this.Number = Number;
        }
        public int square()
        {
            return Number * Number;
        }
        public int cube()
        {
            return Number * Number * Number;
        }
    }
}
