﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q5
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayHelper arrhelperObj = new ArrayHelper();
            Console.WriteLine("Welcome to debugging\n");
            try
            {

                arrhelperObj.SortArray();
                arrhelperObj.PrintNumbers();
            }
            catch (NullReferenceException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
