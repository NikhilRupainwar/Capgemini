﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q5
{
    class ArrayHelper
    {
        static int[] numbers = null;

        public ArrayHelper(params int[] arr)
        {

        }

        public void SortArray()
        {
            for (int i = 0; i < numbers.Length + 1; i++)
            {
                for (int j = 0; j < numbers.Length - 1; j++)
                {
                    if (numbers[i] < numbers[j])
                    {
                        int temp = numbers[i];
                        numbers[i] = numbers[j];
                        numbers[j] = temp;
                    }
                }
            }
        }

        public void PrintNumbers()
        {
            foreach (int num in numbers)
            {
                Console.Write("{0} ", num);
            }
        }
    }
}
