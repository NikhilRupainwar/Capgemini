﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab2Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] doubledim = new int[5, 6];
            Console.WriteLine("Enter data for double dimension array");
            for (int i = 0; i < doubledim.GetLength(0); i++)
            {
                Console.Write("Enter Element");
                for (int j = 0; j < doubledim.GetLength(1); j++)
                {

                    doubledim[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("Elements of Double Dimension Array");
            for (int i = 0; i < doubledim.GetLength(0); i++)
            {
                for (int j = 0; j < doubledim.GetLength(1); j++)
                {
                    Console.Write(doubledim[i, j] + "\t");
                }
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
