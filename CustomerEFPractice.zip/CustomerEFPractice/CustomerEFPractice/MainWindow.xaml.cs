﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CustomerEFPractice
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_Display_Click(object sender, RoutedEventArgs e)
        {
            Sep19CHNEntities contextObj = new CustomerEFPractice.Sep19CHNEntities();
            if (txt_custRegion.Text != string.Empty)
            {
                var query = from Customer cust in contextObj.Customers
                            where cust.CustRegion == txt_custRegion.Text  // filters
                            select cust;
                List<Customer> clist = new List<CustomerEFPractice.Customer>(); // collection concept
                clist = query.ToList<Customer>();
                if (clist.Count <= 0) MessageBox.Show("No records found");

                dg_Cust.ItemsSource = clist;
            }
            else MessageBox.Show("Please enter Location");
        }

        private void btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new CustomerEFPractice.Sep19CHNEntities();
                Customer custToBeDeleted; 
                int cID = Convert.ToInt32(txt_custId.Text);
                custToBeDeleted = contextObj.Customers.FirstOrDefault(cust => cust.CustID == cID);
                if (custToBeDeleted != null)
                {
                    contextObj.Customers.Remove(custToBeDeleted);
                    contextObj.SaveChanges();
                    MessageBox.Show("Employee details deleted");
                }
                else throw new Exception("Delete could not be done");
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
