﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace Day01
{
    public partial class StudentForm : Form
    {
        SqlConnection studentCon;
        SqlCommand studentcmd;
        SqlDataReader studentReader;
        SqlDataAdapter studentAdapter;
        DataSet studentDataSet;
        string conStr;
        public StudentForm()
        {
            InitializeComponent();
        }

        private void StudentForm_Load(object sender, EventArgs e)
        {
            studentCon = new SqlConnection(@"Data Source=ndamssql\sqlilearn;Initial Catalog = ChennaiTraining_21Dec;User Id= sqluser;Password=sqluser");
            studentcmd = new SqlCommand();
            studentcmd.Connection = studentCon;
            studentcmd.CommandText = "usp_nxtStudentId2";
            studentcmd.CommandType = CommandType.StoredProcedure;
            SqlParameter param = new SqlParameter();
            param.ParameterName = "@NewSID";
            param.Direction = ParameterDirection.Output ;
            try
            {
                studentCon.Open();
                               
                textBox1.Text = studentcmd.ExecuteScalar ().ToString();
            }
            #region catch block
            catch (SqlException se)
            {
                MessageBox.Show("SQL Error Occurred " + se.Message);
            }
            catch (Exception se)
            {
                MessageBox.Show("An Error Occurred " + se.Message);
            }
            #endregion
            finally
            { 
               if(studentReader!=null)
                studentReader.Close();
               if (studentCon.State == ConnectionState.Open)
                   studentCon.Close();

            
            }
        
        }
    }
}
