﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DBFTEST
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new DBFTEST.Sep19CHNEntities();
                var query = from Customer cust in contextObj.Customers
                            select cust;
                displayDataGrid.ItemsSource = query.ToList();

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void btnDeleted_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new DBFTEST.Sep19CHNEntities();
                int deleteID = Convert.ToInt32(txtCustId.Text);
                Customer custDelete = new DBFTEST.Customer();
                custDelete = contextObj.Customers.FirstOrDefault(cust => cust.CustId == deleteID);
                if (custDelete != null)
                {
                    contextObj.Customers.Remove(custDelete);
                    contextObj.SaveChanges();
                    MessageBox.Show("Deleted Successfully");
                }
                else
                    throw new Exception("Customer Not Deleted");
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Sep19CHNEntities contextObj = new DBFTEST.Sep19CHNEntities();
                int searchID = Convert.ToInt32(txtCustId.Text);
                Customer custSearch = new DBFTEST.Customer();
                var query = from Customer cust in contextObj.Customers where cust.CustId == searchID 
                            select cust ;
                
                displayDataGrid.ItemsSource = query.ToList();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }

        }

        private void btnVieewInRange_Click(object sender, RoutedEventArgs e)
        {
            DateTime d1 = Convert.ToDateTime(startDate.Text.ToString());
            DateTime d2 = Convert.ToDateTime(endDate.Text.ToString());
            try
            {
                Sep19CHNEntities contextObj = new DBFTEST.Sep19CHNEntities();
                
                Customer custSearch = new DBFTEST.Customer();
                var query = from Customer cust in contextObj.Customers
                            where cust.DOB >= d1 && cust.DOB <= d2
                select cust;

                displayDataGrid.ItemsSource = query.ToList();
                
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.ToString());
            }
        }

        
    }
}
