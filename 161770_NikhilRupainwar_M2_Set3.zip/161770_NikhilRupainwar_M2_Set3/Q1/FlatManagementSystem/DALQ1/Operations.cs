﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EntityQ1;
using ExceptionQ1;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
/// <summary>
/// Name : Nikhil Rupainwar
/// Employee ID : 161770
/// Date : 17/10/2018
/// </summary>
namespace DALQ1
{
    public class Operations
    {
        static string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection empConnObj;
        SqlCommand empCommand;
        DataTable dtDept;
        SqlDataReader empReader = null;
        public Operations()
        {
            empConnObj = new SqlConnection();
            empConnObj.ConnectionString = empConnStr;
        }

        public int AddOwner_DAL(Entity own)  // register of owner for flat
        {
            int rowsAffected = 0;
            try
            {


                empCommand = new SqlCommand("Nikhil.usp_AddOwner", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empCommand.Parameters.AddWithValue("@ownerFName", own.OwnerFName);
                empCommand.Parameters.AddWithValue("@ownerLName", own.OwnerLName);
                empCommand.Parameters.AddWithValue("@ownerMob", own.OwnerMob);
                empCommand.Parameters.AddWithValue("@ownerFlatType", own.FlatType);
                empCommand.Parameters.AddWithValue("@ownerFlatArea", own.FlatArea);
                empCommand.Parameters.AddWithValue("@DRA", own.DRA);
                empCommand.Parameters.AddWithValue("@DDA", own.DDA);
                empConnObj.Open();
                rowsAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowsAffected;

        }

        public DataTable LoadFlatDes()
        {

            try
            {
                dtDept = new DataTable();
                empCommand = new SqlCommand("Nikhil.usp_DisplayFlat", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                dtDept.Load(empReader);

            }
            catch (SqlException)
            {
                throw;

            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return dtDept;
        }  // loading flat description

    }
}
