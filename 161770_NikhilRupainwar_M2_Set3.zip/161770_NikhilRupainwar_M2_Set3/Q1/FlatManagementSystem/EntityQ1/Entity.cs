﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Name : Nikhil Rupainwar
/// Employee ID : 161770
/// Date : 17/10/2018
/// </summary>
namespace EntityQ1
{
    public class Entity
    {
        public int FlatId { get; set; }
        public string OwnerFName { get; set; }
        public string OwnerLName { get; set; }
        public long OwnerMob { get; set; }
        public string FlatType { get; set; }
        public int FlatArea { get; set; }
        public int DRA { get; set; }
        public int DDA { get; set; }
    }
}
