﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DALQ1;
using EntityQ1;
using ExceptionQ1;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
/// <summary>
/// Name : Nikhil Rupainwar
/// Employee ID : 161770
/// Date : 17/10/2018
/// </summary>
namespace BLL_Q1
{
    public class Validations
    {
        Operations ownOperation;

        public DataTable LoadFlat_BLL()
        {
            DataTable dtDept;
            try
            {
                ownOperation = new Operations();
                dtDept = ownOperation.LoadFlatDes();
            }
            catch (SqlException se)
            {

                throw se;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dtDept;
        } // load flat in BLL

        public bool validate(Entity newOwn)  // Validations
        {
            bool isValid = true;
            StringBuilder sbError = new StringBuilder();
            try
            {
                // first name
                if (newOwn.OwnerFName == string.Empty)
                {
                    isValid = false;
                    sbError.Append("Please enter First Name");
                }

                else if (!Regex.IsMatch(newOwn.OwnerFName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("First Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValid = false;
                }
                if (!isValid) throw new OwnerException(sbError.ToString());
                // last name
                if (newOwn.OwnerLName == string.Empty)
                {
                    isValid = false;
                    sbError.Append("Please enter Last Name");
                }
                else if (!Regex.IsMatch(newOwn.OwnerLName, "[A-Z][a-z]{2,}"))
                {
                    sbError.Append("Last Name should start with Capital Alphabet, it should have minimum 3 characters and only alphabets\n");
                    isValid = false;
                }
                if (!isValid) throw new OwnerException(sbError.ToString());
                // phone no
                if (!Regex.IsMatch(Convert.ToString(newOwn.OwnerMob), "[7-9][0-9]{9}"))
                {
                    sbError.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
                    isValid = false;
                }
                if (isValid == false)
                    throw new OwnerException(sbError.ToString());
                // Flat Area
                if (!Regex.IsMatch(Convert.ToString(newOwn.FlatArea), "[0-9]{1,}"))
                {
                    sbError.Append("Flat Area should start with 1 and may contain any further digits\n");
                    isValid = false;
                }
                if (isValid == false)
                    throw new OwnerException(sbError.ToString());
                // Rent Amount
                if (!Regex.IsMatch(Convert.ToString(newOwn.DRA), "[0-9]{1,}"))
                {
                    sbError.Append("Rent Amount should start with 1 and may contain any further digits\n");
                    isValid = false;
                }
                if (isValid == false)
                    throw new OwnerException(sbError.ToString());
                // Deposit Amount
                if (!Regex.IsMatch(Convert.ToString(newOwn.DDA), "[0-9]{1,}") && newOwn.DDA < newOwn.DRA)
                {
                    sbError.Append("Deposit Amount should start with 1 and may contain any further digits and should not be less than Rent Amount\n");
                    isValid = false;
                }
                if (isValid == false)
                    throw new OwnerException(sbError.ToString());
            }
            catch (OwnerException ex)
            { throw ex; }

            return isValid;
        }

        public int AddOwner_BLL(Entity newOwn)  // Add Owner Details--Registration
        {
            int rowsAffected = 0;
            Operations operationObj;
            try
            {
                if (validate(newOwn))
                {
                    operationObj = new Operations();
                    rowsAffected = operationObj.AddOwner_DAL(newOwn);
                }
            }
            catch (OwnerException ex) { throw ex; }
            catch (SqlException se) { throw se; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;

        }

    }
}
