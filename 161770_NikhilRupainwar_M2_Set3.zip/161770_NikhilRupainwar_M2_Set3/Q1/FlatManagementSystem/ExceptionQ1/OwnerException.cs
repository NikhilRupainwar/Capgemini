﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Name : Nikhil Rupainwar
/// Employee ID : 161770
/// Date : 17/10/2018
/// </summary>
namespace ExceptionQ1
{
    public class OwnerException : ApplicationException
    {
        public OwnerException()
            : base()
        { }

        public OwnerException(string Message) : base(Message)
        { }
    }
}
