

create table Nikhil.Flat
(
FlatId int identity(1,1) primary key,
OwnerFName varchar(25) unique not null,
OwnerLName varchar(25) unique not null,
OwnerMob bigint not null
)




/* add */
create proc Nikhil.usp_AddOwner
@ownerFName varchar(20),
@ownerLName varchar(20),
@ownerMob bigint
AS
BEGIN
insert into Nikhil.Flat values(@ownerFName,@ownerLName,@ownerMob)
END



create table Nikhil.FlatDescription
(
FlatID int identity(1,1) primary key,
FlatType varchar(20),
FlatArea int,
DRA int,
DDA int
);

drop table Nikhil.FlatDescription

create proc Nikhil.usp_DisplayFlat
@FlatType varchar(20),
@FlatArea int,
@DRA int,
@DDA int
AS
BEGIN
select * from Nikhil.FlatDescription
END