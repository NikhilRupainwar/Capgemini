
create table Nikhil.Owner
(

OwnerFName varchar(25) unique not null,
OwnerLName varchar(25) unique not null,
OwnerMob bigint not null,
FlatType varchar(25),
FlatArea int,
DRA int primary key,
DDA int
)

